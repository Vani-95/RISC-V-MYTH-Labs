#include <stdio.h>
#include <math.h>

int main() {
		//unsigned long long int max= (unsigned long long int) (pow(2,270)-1);
	 	long long int max= (long long int) (pow(2,5)* -1);
		printf("The highest number represented by unsigned long long int is %lld\n",max);
		return 0;
}
